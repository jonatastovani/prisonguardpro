-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: pgp
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `pgp`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `pgp` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `pgp`;

--
-- Table structure for table `categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `descricao`, `created_at`, `updated_at`) VALUES (1,'soluta','Excepturi temporibus fugit maiores distinctio. At nam architecto atque autem praesentium. Dolorum quae qui aut amet qui id perspiciatis. Quasi laudantium enim laboriosam at porro quia voluptas.','2023-11-25 23:54:23','2023-11-25 23:54:23'),(2,'inventore','Et est eum labore ducimus. Repellendus delectus laborum reiciendis quisquam natus id. Consequatur et molestiae optio facere perspiciatis mollitia reprehenderit voluptas.','2023-11-25 23:54:23','2023-11-25 23:54:23'),(3,'voluptate','Facilis ut dolor ipsum qui consequatur. Nobis est aut repellat voluptas deleniti quibusdam. Quis omnis cupiditate expedita mollitia sapiente.','2023-11-25 23:54:23','2023-11-25 23:54:23'),(4,'aliquid','Voluptatem inventore sed ut autem nemo tenetur. Qui iure non sed eaque omnis. Tempora incidunt non facere animi modi assumenda officia.','2023-11-25 23:54:23','2023-11-25 23:54:23'),(5,'sint','Facere quis neque et iure aliquid expedita cumque rerum. Ea cupiditate laborum doloremque. Et exercitationem nobis facilis. Incidunt voluptatem magni facere aliquid ab et.','2023-11-25 23:54:23','2023-11-25 23:54:23');

--
-- Table structure for table `failed_jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--


--
-- Table structure for table `migrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (29,'2014_10_12_000000_create_users_table',1),(30,'2014_10_12_100000_create_password_reset_tokens_table',1),(31,'2019_08_19_000000_create_failed_jobs_table',1),(32,'2019_12_14_000001_create_personal_access_tokens_table',1),(33,'2023_11_25_184040_create_categorias_table',1),(34,'2023_11_25_184041_produtos',1),(35,'2023_11_25_200543_create_ref_estados_table',1);

--
-- Table structure for table `password_reset_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--


--
-- Table structure for table `personal_access_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--


--
-- Table structure for table `produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco` double(10,2) NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_user` bigint unsigned NOT NULL,
  `id_categoria` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `produtos_id_user_foreign` (`id_user`),
  KEY `produtos_id_categoria_foreign` (`id_categoria`),
  CONSTRAINT `produtos_id_categoria_foreign` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `produtos_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--


--
-- Table structure for table `ref_estados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ref_estados` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sigla` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_user_created` bigint unsigned NOT NULL,
  `ip_created` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_user_updated` bigint unsigned DEFAULT NULL,
  `ip_updated` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_user_deleted` bigint unsigned DEFAULT NULL,
  `ip_deleted` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ref_estados_sigla_unique` (`sigla`),
  UNIQUE KEY `ref_estados_nome_unique` (`nome`),
  KEY `ref_estados_id_user_created_foreign` (`id_user_created`),
  KEY `ref_estados_id_user_updated_foreign` (`id_user_updated`),
  KEY `ref_estados_id_user_deleted_foreign` (`id_user_deleted`),
  CONSTRAINT `ref_estados_id_user_created_foreign` FOREIGN KEY (`id_user_created`) REFERENCES `users` (`id`),
  CONSTRAINT `ref_estados_id_user_deleted_foreign` FOREIGN KEY (`id_user_deleted`) REFERENCES `users` (`id`),
  CONSTRAINT `ref_estados_id_user_updated_foreign` FOREIGN KEY (`id_user_updated`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_estados`
--

INSERT INTO `ref_estados` (`id`, `sigla`, `nome`, `id_user_created`, `ip_created`, `id_user_updated`, `ip_updated`, `id_user_deleted`, `ip_deleted`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'AC','Acre',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'AL','Alagoas',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'AP','Amapá',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'AM','Amazonas',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'BA','Bahia',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'CE','Ceará',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'DF','Distrito Federal',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'ES','Espírito Santo',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'GO','Goiás',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'MA','Maranhão',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'MT','Mato Grosso',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'MS','Mato Grosso do Sul',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'MG','Minas Gerais',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'PA','Pará',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'PB','Paraíba',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'PR','Paraná',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'PE','Pernambuco',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'PI','Piauí',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'RJ','Rio de Janeiro',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'RN','Rio Grande do Norte',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'RS','Rio Grande do Sul',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'RO','Rondônia',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'RR','Roraima',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'SC','Santa Catarina',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'SP','São Paulo',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'SE','Sergipe',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'TO','Tocantins',1,'172.14.239.101',NULL,NULL,NULL,NULL,NULL,NULL,NULL);

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Jônatas','Tovani','jonatas@teste.com',NULL,'$2y$12$8OoLIkjKGraFvErScbFhv.1KpsDYMigbRgJuOxDw.kXfNCBdgHpWu',NULL,'2023-11-25 23:54:23','2023-11-25 23:54:23');

--
-- Dumping routines for database 'pgp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-25 18:03:34
